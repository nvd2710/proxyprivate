<?php
/**
 * API Đăng ký - ProxyPrivate.vn
 * File: api/auth/register.php
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Chỉ cho phép POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'Phương thức không được hỗ trợ'
    ]);
    exit;
}

require_once '../config/database.php';
require_once '../config/functions.php';

try {
    // Kiểm tra xem có cho phép đăng ký không
    $enable_registration = getSetting('enable_registration', '1');
    if ($enable_registration !== '1') {
        throw new Exception('Hệ thống hiện tại không cho phép đăng ký tài khoản mới');
    }
    
    // Lấy dữ liệu JSON từ request
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        throw new Exception('Dữ liệu đầu vào không hợp lệ');
    }
    
    $name = trim($input['name'] ?? '');
    $email = trim($input['email'] ?? '');
    $phone = trim($input['phone'] ?? '');
    $password = $input['password'] ?? '';
    
    // Validate dữ liệu đầu vào
    if (empty($name)) {
        throw new Exception('Họ và tên không được để trống');
    }
    
    if (strlen($name) < 2 || strlen($name) > 100) {
        throw new Exception('Họ và tên phải từ 2-100 ký tự');
    }
    
    if (empty($email)) {
        throw new Exception('Email không được để trống');
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception('Email không đúng định dạng');
    }
    
    if (strlen($email) > 255) {
        throw new Exception('Email quá dài');
    }
    
    if (empty($password)) {
        throw new Exception('Mật khẩu không được để trống');
    }
    
    if (strlen($password) < 6) {
        throw new Exception('Mật khẩu phải có ít nhất 6 ký tự');
    }
    
    if (strlen($password) > 128) {
        throw new Exception('Mật khẩu quá dài');
    }
    
    // Validate số điện thoại nếu có
    if (!empty($phone)) {
        $phone = preg_replace('/[^0-9+]/', '', $phone);
        if (strlen($phone) < 10 || strlen($phone) > 15) {
            throw new Exception('Số điện thoại không hợp lệ');
        }
    }
    
    // Kiểm tra rate limiting (tối đa 3 lần đăng ký trong 1 giờ)
    $client_ip = getClientIP();
    $rate_limit_key = "register_attempts_{$client_ip}";
    
    if (isRateLimited($rate_limit_key, 3, 3600)) { // 3 attempts in 1 hour
        throw new Exception('Quá nhiều lần đăng ký. Vui lòng thử lại sau 1 giờ');
    }
    
    // Bắt đầu transaction
    $pdo->beginTransaction();
    
    try {
        // Kiểm tra email đã tồn tại chưa
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            throw new Exception('Email này đã được sử dụng');
        }
        
        // Kiểm tra số điện thoại đã tồn tại chưa (nếu có)
        if (!empty($phone)) {
            $stmt = $pdo->prepare("SELECT id FROM users WHERE phone = ?");
            $stmt->execute([$phone]);
            if ($stmt->fetch()) {
                throw new Exception('Số điện thoại này đã được sử dụng');
            }
        }
        
        // Tạo API key unique
        do {
            $api_key = generateApiKey();
            $stmt = $pdo->prepare("SELECT id FROM users WHERE api_key = ?");
            $stmt->execute([$api_key]);
        } while ($stmt->fetch());
        
        // Hash password
        $password_hash = password_hash($password, PASSWORD_ARGON2ID, [
            'memory_cost' => 65536, // 64 MB
            'time_cost' => 4,       // 4 iterations
            'threads' => 3,         // 3 threads
        ]);
        
        // Insert user mới
        $stmt = $pdo->prepare("
            INSERT INTO users (name, email, phone, password_hash, api_key, status, created_at)
            VALUES (?, ?, ?, ?, ?, 'inactive', NOW())
        ");
        $stmt->execute([$name, $email, $phone ?: null, $password_hash, $api_key]);
        
        $user_id = $pdo->lastInsertId();
        
        // Tạo email verification token
        $verification_token = generateSecureToken(64);
        $expires_at = date('Y-m-d H:i:s', strtotime('+24 hours'));
        
        $stmt = $pdo->prepare("
            INSERT INTO email_verification_tokens (user_id, token, expires_at)
            VALUES (?, ?, ?)
        ");
        $stmt->execute([$user_id, $verification_token, $expires_at]);
        
        // Tạo thông báo chào mừng
        $stmt = $pdo->prepare("
            INSERT INTO notifications (user_id, title, content, type)
            VALUES (?, ?, ?, 'info')
        ");
        $welcome_message = "Chào mừng bạn đến với ProxyPrivate.vn! Vui lòng xác thực email để kích hoạt tài khoản.";
        $stmt->execute([$user_id, 'Chào mừng!', $welcome_message]);
        
        // Gửi email xác thực
        $verification_link = getBaseUrl() . "/verify-email?token=" . $verification_token;
        $email_subject = "Xác thực tài khoản ProxyPrivate.vn";
        $email_body = getEmailTemplate('email_verification', [
            'name' => $name,
            'verification_link' => $verification_link,
            'expires_hours' => 24
        ]);
        
        if (!sendEmail($email, $email_subject, $email_body)) {
            // Log warning nhưng không fail transaction
            error_log("Failed to send verification email to: " . $email);
        }
        
        // Log hoạt động
        logActivity($user_id, 'user_registered', 'user', $user_id, 
                   'Đăng ký tài khoản mới từ IP: ' . $client_ip);
        
        // Commit transaction
        $pdo->commit();
        
        // Tăng rate limiting counter
        incrementRateLimit($rate_limit_key, 3600);
        
        // Response thành công
        echo json_encode([
            'success' => true,
            'message' => 'Đăng ký thành công! Chúng tôi đã gửi email xác thực đến ' . $email . '. Vui lòng kiểm tra hộp thư để kích hoạt tài khoản.',
            'user_id' => $user_id,
            'verification_required' => true
        ]);
        
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
    
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
} catch (PDOException $e) {
    error_log("Database error in register: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Lỗi hệ thống. Vui lòng thử lại sau'
    ]);
}
?>