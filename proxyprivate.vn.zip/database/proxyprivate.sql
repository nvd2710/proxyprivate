-- Database cho ProxyPrivate.vn
-- Tạo database và các bảng cần thiết

-- Bảng người dùng
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL COMMENT 'Họ và tên',
    email VARCHAR(255) UNIQUE NOT NULL COMMENT 'Email đăng nhập',
    phone VARCHAR(20) COMMENT 'Số điện thoại',
    password_hash VARCHAR(255) NOT NULL COMMENT 'Mật khẩu đã mã hóa',
    api_key VARCHAR(100) UNIQUE NOT NULL COMMENT 'API key riêng',
    balance DECIMAL(15,2) DEFAULT 0.00 COMMENT 'Số dư tài khoản (VND)',
    currency VARCHAR(3) DEFAULT 'VND' COMMENT 'Loại tiền tệ',
    avatar VARCHAR(255) COMMENT 'Đường dẫn ảnh đại diện',
    birthday DATE COMMENT 'Ngày sinh',
    address TEXT COMMENT 'Địa chỉ',
    status ENUM('active', 'inactive', 'banned') DEFAULT 'inactive' COMMENT 'Trạng thái tài khoản',
    email_verified_at TIMESTAMP NULL COMMENT 'Thời gian xác thực email',
    last_login_at TIMESTAMP NULL COMMENT 'Lần đăng nhập cuối',
    last_login_ip VARCHAR(45) COMMENT 'IP đăng nhập cuối',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Thời gian tạo',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Thời gian cập nhật',
    
    INDEX idx_email (email),
    INDEX idx_api_key (api_key),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
) COMMENT 'Bảng thông tin người dùng';

-- Bảng proxy
CREATE TABLE proxies (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL COMMENT 'ID người dùng sở hữu',
    external_id VARCHAR(50) COMMENT 'ID từ hệ thống proxy bên ngoài',
    ip_address VARCHAR(45) NOT NULL COMMENT 'Địa chỉ IP proxy',
    host VARCHAR(45) NOT NULL COMMENT 'Host kết nối',
    port INT NOT NULL COMMENT 'Cổng kết nối',
    username VARCHAR(50) NOT NULL COMMENT 'Tên đăng nhập proxy',
    password VARCHAR(50) NOT NULL COMMENT 'Mật khẩu proxy',
    type ENUM('http', 'https', 'socks4', 'socks5') NOT NULL COMMENT 'Loại proxy',
    protocol_version ENUM('ipv4', 'ipv6', 'ipv4_shared') NOT NULL COMMENT 'Phiên bản giao thức',
    country_code VARCHAR(2) NOT NULL COMMENT 'Mã quốc gia (ISO 2)',
    country_name VARCHAR(100) COMMENT 'Tên quốc gia',
    city VARCHAR(100) COMMENT 'Thành phố',
    status ENUM('active', 'expired', 'suspended') DEFAULT 'active' COMMENT 'Trạng thái proxy',
    expires_at TIMESTAMP NOT NULL COMMENT 'Thời gian hết hạn',
    last_checked_at TIMESTAMP NULL COMMENT 'Lần kiểm tra cuối',
    is_working BOOLEAN DEFAULT TRUE COMMENT 'Proxy có hoạt động không',
    bandwidth_used BIGINT DEFAULT 0 COMMENT 'Băng thông đã sử dụng (bytes)',
    max_bandwidth BIGINT COMMENT 'Giới hạn băng thông (bytes)',
    comment TEXT COMMENT 'Ghi chú của người dùng',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Thời gian tạo',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Thời gian cập nhật',
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_status (status),
    INDEX idx_expires_at (expires_at),
    INDEX idx_country_code (country_code),
    INDEX idx_external_id (external_id)
) COMMENT 'Bảng quản lý proxy';

-- Bảng đơn hàng
CREATE TABLE orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL COMMENT 'ID người dùng',
    order_number VARCHAR(20) UNIQUE NOT NULL COMMENT 'Số đơn hàng',
    type ENUM('buy_proxy', 'extend_proxy', 'topup_balance') NOT NULL COMMENT 'Loại đơn hàng',
    proxy_type ENUM('ipv4', 'ipv6', 'ipv4_shared') COMMENT 'Loại proxy mua',
    proxy_count INT COMMENT 'Số lượng proxy',
    proxy_period INT COMMENT 'Thời gian proxy (ngày)',
    country_code VARCHAR(2) COMMENT 'Mã quốc gia proxy',
    protocol ENUM('http', 'https', 'socks4', 'socks5') COMMENT 'Giao thức proxy',
    amount DECIMAL(15,2) NOT NULL COMMENT 'Số tiền đơn hàng',
    currency VARCHAR(3) DEFAULT 'VND' COMMENT 'Loại tiền tệ',
    discount_amount DECIMAL(15,2) DEFAULT 0.00 COMMENT 'Số tiền giảm giá',
    final_amount DECIMAL(15,2) NOT NULL COMMENT 'Số tiền cuối cùng',
    status ENUM('pending', 'processing', 'completed', 'failed', 'cancelled') DEFAULT 'pending' COMMENT 'Trạng thái đơn hàng',
    payment_method ENUM('balance', 'bank_transfer', 'momo', 'zalopay', 'vnpay', 'paypal') COMMENT 'Phương thức thanh toán',
    payment_status ENUM('pending', 'paid', 'failed', 'refunded') DEFAULT 'pending' COMMENT 'Trạng thái thanh toán',
    notes TEXT COMMENT 'Ghi chú đơn hàng',
    processed_at TIMESTAMP NULL COMMENT 'Thời gian xử lý',
    completed_at TIMESTAMP NULL COMMENT 'Thời gian hoàn thành',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Thời gian tạo',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Thời gian cập nhật',
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_order_number (order_number),
    INDEX idx_status (status),
    INDEX idx_payment_status (payment_status),
    INDEX idx_created_at (created_at)
) COMMENT 'Bảng đơn hàng';

-- Bảng giao dịch thanh toán
CREATE TABLE transactions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL COMMENT 'ID người dùng',
    order_id INT COMMENT 'ID đơn hàng (nếu có)',
    transaction_id VARCHAR(100) UNIQUE NOT NULL COMMENT 'Mã giao dịch',
    type ENUM('deposit', 'withdrawal', 'payment', 'refund', 'bonus') NOT NULL COMMENT 'Loại giao dịch',
    amount DECIMAL(15,2) NOT NULL COMMENT 'Số tiền giao dịch',
    currency VARCHAR(3) DEFAULT 'VND' COMMENT 'Loại tiền tệ',
    balance_before DECIMAL(15,2) NOT NULL COMMENT 'Số dư trước giao dịch',
    balance_after DECIMAL(15,2) NOT NULL COMMENT 'Số dư sau giao dịch',
    payment_method ENUM('balance', 'bank_transfer', 'momo', 'zalopay', 'vnpay', 'paypal') COMMENT 'Phương thức thanh toán',
    gateway_transaction_id VARCHAR(255) COMMENT 'Mã giao dịch từ cổng thanh toán',
    gateway_response TEXT COMMENT 'Phản hồi từ cổng thanh toán',
    status ENUM('pending', 'completed', 'failed', 'cancelled') DEFAULT 'pending' COMMENT 'Trạng thái giao dịch',
    description TEXT COMMENT 'Mô tả giao dịch',
    ip_address VARCHAR(45) COMMENT 'Địa chỉ IP thực hiện giao dịch',
    user_agent TEXT COMMENT 'User agent',
    processed_at TIMESTAMP NULL COMMENT 'Thời gian xử lý',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Thời gian tạo',
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_order_id (order_id),
    INDEX idx_transaction_id (transaction_id),
    INDEX idx_type (type),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
) COMMENT 'Bảng giao dịch thanh toán';

-- Bảng phiên đăng nhập
CREATE TABLE user_sessions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL COMMENT 'ID người dùng',
    session_token VARCHAR(255) UNIQUE NOT NULL COMMENT 'Token phiên đăng nhập',
    device_info TEXT COMMENT 'Thông tin thiết bị',
    ip_address VARCHAR(45) COMMENT 'Địa chỉ IP',
    user_agent TEXT COMMENT 'User agent',
    last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Hoạt động cuối',
    expires_at TIMESTAMP NOT NULL COMMENT 'Thời gian hết hạn',
    is_active BOOLEAN DEFAULT TRUE COMMENT 'Phiên có hoạt động không',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Thời gian tạo',
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_session_token (session_token),
    INDEX idx_expires_at (expires_at),
    INDEX idx_is_active (is_active)
) COMMENT 'Bảng phiên đăng nhập';

-- Bảng cấu hình hệ thống
CREATE TABLE system_settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    setting_key VARCHAR(100) UNIQUE NOT NULL COMMENT 'Khóa cấu hình',
    setting_value TEXT COMMENT 'Giá trị cấu hình',
    setting_type ENUM('string', 'integer', 'float', 'boolean', 'json') DEFAULT 'string' COMMENT 'Kiểu dữ liệu',
    description TEXT COMMENT 'Mô tả cấu hình',
    is_public BOOLEAN DEFAULT FALSE COMMENT 'Có thể truy cập công khai',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Thời gian tạo',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Thời gian cập nhật',
    
    INDEX idx_setting_key (setting_key),
    INDEX idx_is_public (is_public)
) COMMENT 'Bảng cấu hình hệ thống';

-- Bảng log hoạt động
CREATE TABLE activity_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT COMMENT 'ID người dùng (null nếu là hệ thống)',
    action VARCHAR(100) NOT NULL COMMENT 'Hành động thực hiện',
    resource_type VARCHAR(50) COMMENT 'Loại tài nguyên (user, proxy, order, etc.)',
    resource_id INT COMMENT 'ID tài nguyên',
    description TEXT COMMENT 'Mô tả chi tiết',
    metadata JSON COMMENT 'Dữ liệu bổ sung (JSON)',
    ip_address VARCHAR(45) COMMENT 'Địa chỉ IP',
    user_agent TEXT COMMENT 'User agent',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Thời gian tạo',
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_action (action),
    INDEX idx_resource_type (resource_type),
    INDEX idx_resource_id (resource_id),
    INDEX idx_created_at (created_at)
) COMMENT 'Bảng log hoạt động hệ thống';

-- Bảng mã giảm giá
CREATE TABLE discount_codes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(50) UNIQUE NOT NULL COMMENT 'Mã giảm giá',
    type ENUM('percentage', 'fixed_amount') NOT NULL COMMENT 'Loại giảm giá',
    value DECIMAL(10,2) NOT NULL COMMENT 'Giá trị giảm giá',
    min_order_amount DECIMAL(15,2) DEFAULT 0.00 COMMENT 'Số tiền đơn hàng tối thiểu',
    max_discount_amount DECIMAL(15,2) COMMENT 'Số tiền giảm tối đa',
    usage_limit INT COMMENT 'Giới hạn số lần sử dụng',
    used_count INT DEFAULT 0 COMMENT 'Số lần đã sử dụng',
    user_limit INT DEFAULT 1 COMMENT 'Giới hạn sử dụng per user',
    applies_to ENUM('all', 'proxy_only', 'topup_only') DEFAULT 'all' COMMENT 'Áp dụng cho',
    status ENUM('active', 'inactive', 'expired') DEFAULT 'active' COMMENT 'Trạng thái',
    starts_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Thời gian bắt đầu',
    expires_at TIMESTAMP COMMENT 'Thời gian hết hạn',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Thời gian tạo',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Thời gian cập nhật',
    
    INDEX idx_code (code),
    INDEX idx_status (status),
    INDEX idx_expires_at (expires_at)
) COMMENT 'Bảng mã giảm giá';

-- Bảng sử dụng mã giảm giá
CREATE TABLE discount_code_usages (
    id INT PRIMARY KEY AUTO_INCREMENT,
    discount_code_id INT NOT NULL COMMENT 'ID mã giảm giá',
    user_id INT NOT NULL COMMENT 'ID người dùng',
    order_id INT NOT NULL COMMENT 'ID đơn hàng',
    discount_amount DECIMAL(15,2) NOT NULL COMMENT 'Số tiền được giảm',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Thời gian sử dụng',
    
    FOREIGN KEY (discount_code_id) REFERENCES discount_codes(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    INDEX idx_discount_code_id (discount_code_id),
    INDEX idx_user_id (user_id),
    INDEX idx_order_id (order_id)
) COMMENT 'Bảng lịch sử sử dụng mã giảm giá';

-- Bảng thông báo
CREATE TABLE notifications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT COMMENT 'ID người dùng (null = thông báo toàn hệ thống)',
    title VARCHAR(255) NOT NULL COMMENT 'Tiêu đề thông báo',
    content TEXT NOT NULL COMMENT 'Nội dung thông báo',
    type ENUM('info', 'success', 'warning', 'error', 'system') DEFAULT 'info' COMMENT 'Loại thông báo',
    is_read BOOLEAN DEFAULT FALSE COMMENT 'Đã đọc chưa',
    action_url VARCHAR(255) COMMENT 'Link hành động',
    expires_at TIMESTAMP COMMENT 'Thời gian hết hạn hiển thị',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Thời gian tạo',
    read_at TIMESTAMP NULL COMMENT 'Thời gian đọc',
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_is_read (is_read),
    INDEX idx_type (type),
    INDEX idx_created_at (created_at)
) COMMENT 'Bảng thông báo';

-- Bảng email verification tokens
CREATE TABLE email_verification_tokens (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL COMMENT 'ID người dùng',
    token VARCHAR(255) UNIQUE NOT NULL COMMENT 'Token xác thực',
    expires_at TIMESTAMP NOT NULL COMMENT 'Thời gian hết hạn',
    used_at TIMESTAMP NULL COMMENT 'Thời gian sử dụng',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Thời gian tạo',
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_token (token),
    INDEX idx_expires_at (expires_at)
) COMMENT 'Bảng token xác thực email';

-- Bảng reset password tokens
CREATE TABLE password_reset_tokens (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL COMMENT 'ID người dùng',
    token VARCHAR(255) UNIQUE NOT NULL COMMENT 'Token reset mật khẩu',
    expires_at TIMESTAMP NOT NULL COMMENT 'Thời gian hết hạn',
    used_at TIMESTAMP NULL COMMENT 'Thời gian sử dụng',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Thời gian tạo',
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_token (token),
    INDEX idx_expires_at (expires_at)
) COMMENT 'Bảng token reset mật khẩu';

-- Insert dữ liệu mẫu
INSERT INTO system_settings (setting_key, setting_value, setting_type, description, is_public) VALUES
('site_name', 'ProxyPrivate.vn', 'string', 'Tên website', TRUE),
('site_description', 'Dịch vụ proxy riêng tư chất lượng cao cho người Việt', 'string', 'Mô tả website', TRUE),
('admin_email', 'admin@proxyprivate.vn', 'string', 'Email quản trị', FALSE),
('support_email', 'support@proxyprivate.vn', 'string', 'Email hỗ trợ', TRUE),
('api_proxy_endpoint', 'https://px6.link/api', 'string', 'Endpoint API proxy', FALSE),
('api_proxy_key', '94b8ddc0da-572e9c845e-34c2fa225a', 'string', 'API key proxy service', FALSE),
('currency_exchange_rate', '24000', 'float', 'Tỷ giá USD sang VND', FALSE),
('default_currency', 'VND', 'string', 'Loại tiền tệ mặc định', TRUE),
('min_deposit_amount', '100000', 'integer', 'Số tiền nạp tối thiểu (VND)', TRUE),
('max_deposit_amount', '50000000', 'integer', 'Số tiền nạp tối đa (VND)', TRUE),
('session_lifetime', '7200', 'integer', 'Thời gian sống của session (giây)', FALSE),
('enable_registration', '1', 'boolean', 'Cho phép đăng ký tài khoản mới', TRUE),
('maintenance_mode', '0', 'boolean', 'Chế độ bảo trì', TRUE),
('contact_phone', '+84 123 456 789', 'string', 'Số điện thoại liên hệ', TRUE),
('contact_address', 'Hà Nội, Việt Nam', 'string', 'Địa chỉ liên hệ', TRUE),
('facebook_url', 'https://facebook.com/proxyprivate.vn', 'string', 'Link Facebook', TRUE),
('telegram_url', 'https://t.me/proxyprivate_vn', 'string', 'Link Telegram', TRUE);

-- Insert mã giảm giá mẫu
INSERT INTO discount_codes (code, type, value, min_order_amount, max_discount_amount, usage_limit, applies_to, expires_at) VALUES
('WELCOME10', 'percentage', 10.00, 50000, 10000, 1000, 'all', DATE_ADD(NOW(), INTERVAL 30 DAY)),
('NEWUSER50', 'fixed_amount', 50000, 100000, 50000, 500, 'proxy_only', DATE_ADD(NOW(), INTERVAL 60 DAY)),
('PROXY2025', 'percentage', 15.00, 200000, 50000, 100, 'proxy_only', DATE_ADD(NOW(), INTERVAL 90 DAY));

-- Tạo user admin mẫu (password: admin123456)
INSERT INTO users (name, email, password_hash, api_key, balance, status, email_verified_at) VALUES
('Administrator', 'admin@proxyprivate.vn', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 
CONCAT(SUBSTRING(MD5(RAND()), 1, 10), '-', SUBSTRING(MD5(RAND()), 1, 10), '-', SUBSTRING(MD5(RAND()), 1, 10)), 
1000000, 'active', NOW());

-- Tạo indexes để tối ưu hiệu suất
CREATE INDEX idx_users_email_status ON users(email, status);
CREATE INDEX idx_proxies_user_status ON proxies(user_id, status);
CREATE INDEX idx_orders_user_status ON orders(user_id, status);
CREATE INDEX idx_transactions_user_type ON transactions(user_id, type);
CREATE INDEX idx_activity_logs_user_action ON activity_logs(user_id, action);

-- Tạo view để thống kê
CREATE VIEW user_statistics AS
SELECT 
    u.id,
    u.name,
    u.email,
    u.balance,
    u.status,
    COUNT(DISTINCT p.id) as total_proxies,
    COUNT(DISTINCT CASE WHEN p.status = 'active' THEN p.id END) as active_proxies,
    COUNT(DISTINCT o.id) as total_orders,
    SUM(CASE WHEN t.type = 'deposit' THEN t.amount ELSE 0 END) as total_deposits,
    SUM(CASE WHEN t.type = 'payment' THEN t.amount ELSE 0 END) as total_payments,
    u.created_at as member_since,
    u.last_login_at
FROM users u
LEFT JOIN proxies p ON u.id = p.user_id
LEFT JOIN orders o ON u.id = o.user_id
LEFT JOIN transactions t ON u.id = t.user_id
GROUP BY u.id;

-- Tạo view thống kê hệ thống
CREATE VIEW system_statistics AS
SELECT 
    (SELECT COUNT(*) FROM users WHERE status = 'active') as total_active_users,
    (SELECT COUNT(*) FROM users WHERE DATE(created_at) = CURDATE()) as new_users_today,
    (SELECT COUNT(*) FROM proxies WHERE status = 'active') as total_active_proxies,
    (SELECT COUNT(*) FROM orders WHERE status = 'completed') as total_completed_orders,
    (SELECT SUM(final_amount) FROM orders WHERE status = 'completed') as total_revenue,
    (SELECT SUM(amount) FROM transactions WHERE type = 'deposit' AND status = 'completed') as total_deposits,
    (SELECT COUNT(*) FROM orders WHERE DATE(created_at) = CURDATE()) as orders_today,
    (SELECT AVG(final_amount) FROM orders WHERE status = 'completed') as average_order_value;

-- Trigger để tự động cập nhật balance khi có giao dịch
DELIMITER //

CREATE TRIGGER update_user_balance_after_transaction 
AFTER INSERT ON transactions
FOR EACH ROW
BEGIN
    IF NEW.status = 'completed' THEN
        UPDATE users 
        SET balance = NEW.balance_after 
        WHERE id = NEW.user_id;
    END IF;
END//

-- Trigger để log hoạt động khi tạo đơn hàng
CREATE TRIGGER log_order_creation 
AFTER INSERT ON orders
FOR EACH ROW
BEGIN
    INSERT INTO activity_logs (user_id, action, resource_type, resource_id, description)
    VALUES (NEW.user_id, 'order_created', 'order', NEW.id, 
            CONCAT('Tạo đơn hàng mới: ', NEW.order_number, ' - Giá trị: ', NEW.final_amount, ' ', NEW.currency));
END//

-- Trigger để log khi proxy hết hạn
CREATE TRIGGER log_proxy_expiration
AFTER UPDATE ON proxies
FOR EACH ROW
BEGIN
    IF OLD.status != 'expired' AND NEW.status = 'expired' THEN
        INSERT INTO activity_logs (user_id, action, resource_type, resource_id, description)
        VALUES (NEW.user_id, 'proxy_expired', 'proxy', NEW.id,
                CONCAT('Proxy hết hạn: ', NEW.ip_address, ':', NEW.port));
    END IF;
END//

DELIMITER ;

-- Tạo procedure để làm sạch dữ liệu cũ
DELIMITER //

CREATE PROCEDURE CleanupOldData()
BEGIN
    -- Xóa session hết hạn
    DELETE FROM user_sessions WHERE expires_at < NOW();
    
    -- Xóa token xác thực email đã hết hạn
    DELETE FROM email_verification_tokens WHERE expires_at < NOW();
    
    -- Xóa token reset password đã hết hạn
    DELETE FROM password_reset_tokens WHERE expires_at < NOW();
    
    -- Xóa log hoạt động cũ hơn 90 ngày
    DELETE FROM activity_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL 90 DAY);
    
    -- Xóa thông báo đã hết hạn
    DELETE FROM notifications WHERE expires_at < NOW();
    
    -- Cập nhật trạng thái proxy hết hạn
    UPDATE proxies SET status = 'expired' WHERE status = 'active' AND expires_at < NOW();
END//

DELIMITER ;

-- Tạo event để tự động chạy cleanup mỗi ngày
CREATE EVENT daily_cleanup
ON SCHEDULE EVERY 1 DAY
STARTS CURRENT_TIMESTAMP
DO CALL CleanupOldData();


-- Thêm comment cho database
ALTER DATABASE proxyprivate_vn COMMENT = 'Database cho website ProxyPrivate.vn - Dịch vụ proxy riêng tư';

-- Thông báo hoàn thành
SELECT 'Database ProxyPrivate.vn đã được tạo thành công!' as message;